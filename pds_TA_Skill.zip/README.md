# PDS Course TA — AI Skill

An AI teaching assistant for **Machine Learning for Engineers** ([apmonitor.com/pds](https://apmonitor.com/pds)). Install it in your AI tool of choice and it becomes a course-aware TA: it knows the 15-week schedule, the data engineering pipeline, every case study and TCLab notebook, the course's standard metrics and model menu (with scikit-learn idioms), the [Agentic Engineering](https://apmonitor.com/pds/index.php/Main/AgenticWorkplan) workflow used in the course project, and — most importantly — the course AI policy. It tutors, quizzes, audits pipelines for data leakage, and debugs *with* you; it does not do your graded work *for* you.

The same TA is packaged for **Claude**, **ChatGPT / Codex**, and **Google Gemini**. Pick your tool below.

## Files in this directory

| File | For | Purpose |
|---|---|---|
| [`pds-course-ta.skill`](pds-course-ta.skill) | Claude | Installable skill package (zip of `SKILL.md` + reference files). |
| [`skill/pds-course-ta/SKILL.md`](skill/pds-course-ta/SKILL.md) | Claude (readable) | The Claude skill's main instruction file, viewable on GitHub. |
| [`pds-course-ta-instructions.md`](pds-course-ta-instructions.md) | ChatGPT Custom GPT / Project, Gemini Gem | Condensed TA instructions (under the 8,000-character GPT instruction limit) to paste into the instructions box. |
| [`pds-course-ta-knowledge.md`](pds-course-ta-knowledge.md) | ChatGPT, Gemini, any tool | Combined knowledge file: full course map + course notes. Upload as a knowledge/reference file, or paste as context. |
| [`AGENTS.md`](AGENTS.md) | OpenAI Codex (and other agents that read AGENTS.md) | Drop-in agent instructions for working in a course folder or repo clone. |
| [`GEMINI.md`](GEMINI.md) | Gemini CLI | Identical agent instructions under the filename Gemini CLI reads. |

## Install — Claude

1. Download [`pds-course-ta.skill`](https://github.com/APMonitor/pds/raw/master/TA_Skill/pds-course-ta.skill).
2. In Claude, open **Settings → Capabilities → Skills** and upload the file (or attach the `.skill` file to a chat — if your account allows skill creation, the file card shows a **Save skill** button).
3. Ask a course question in a new conversation; the skill triggers automatically, or invoke it with `/pds-course-ta`.

**Claude Code (terminal):**

```bash
mkdir -p ~/.claude/skills && cd ~/.claude/skills
curl -LO https://github.com/APMonitor/pds/raw/master/TA_Skill/pds-course-ta.skill
unzip pds-course-ta.skill && rm pds-course-ta.skill
```

## Install — ChatGPT

**Custom GPT** (needs a plan that includes GPT creation):

1. Go to **Explore GPTs → Create** (or chatgpt.com/gpts/editor) and open the **Configure** tab.
2. Name it *PDS Course TA*. Paste everything below the horizontal rule of [`pds-course-ta-instructions.md`](pds-course-ta-instructions.md) into **Instructions**.
3. Under **Knowledge**, upload [`pds-course-ta-knowledge.md`](pds-course-ta-knowledge.md).
4. Save (keep it private, or share the link with classmates per your instructor's guidance).

**ChatGPT Projects** (alternative, no GPT creation needed): create a Project, paste the same instructions into the project's custom instructions, and add the knowledge file to the project files.

**Codex** (the agentic coding tool / CLI): copy [`AGENTS.md`](AGENTS.md) and [`pds-course-ta-knowledge.md`](pds-course-ta-knowledge.md) into the folder where you run Codex — e.g., your course work folder or a clone of this repository (Codex picks up `AGENTS.md` automatically from the working directory tree).

## Install — Google Gemini

**Gemini Gem:**

1. In Gemini, open **Gems → New Gem** (gem manager).
2. Name it *PDS Course TA*. Paste everything below the horizontal rule of [`pds-course-ta-instructions.md`](pds-course-ta-instructions.md) into the Gem's instructions.
3. Add [`pds-course-ta-knowledge.md`](pds-course-ta-knowledge.md) as a knowledge file (if your Gemini version doesn't support knowledge uploads, paste its contents at the end of the instructions or into your first message).
4. Save and start chatting.

**Gemini CLI:** copy [`GEMINI.md`](GEMINI.md) and [`pds-course-ta-knowledge.md`](pds-course-ta-knowledge.md) into the folder where you run the CLI; it reads `GEMINI.md` automatically.

**No special features available?** Every tool falls back to the same trick: paste `pds-course-ta-instructions.md` (below its horizontal rule) plus `pds-course-ta-knowledge.md` as the first message of a conversation.

## Use

Talk to it like a TA at office hours. Examples of things it does well:

- **Concept help** — *"Why does applying SMOTE before the train/test split leak information, and how much can it inflate my score?"*
- **Homework coaching** — *"My sonar SVM gets 95% train accuracy and 68% test — what's going on?"* (It will walk you through the bias-variance diagnosis and the small-sample reshuffle check rather than handing you numbers.)
- **Quiz me** — *"Quiz me on confusion-matrix metrics, one question at a time, and keep score."* Every assignment's Generative AI Learning section has ready-made prompts like this.
- **Planted-bug practice** — *"Write a cleansing pipeline with one hidden bug; I'll find it."* The course assignments use this pattern; the TA plays it straight and won't reveal early.
- **Pipeline audits** — paste your project pipeline and it hunts train/test contamination, target leakage, and dishonest metrics before your instructor does.
- **Code and TCLab debugging** — paste your pandas/scikit-learn/TensorFlow error; it knows the `tclab` package and the digital twin (`tclab.setup(connected=False)`).
- **Report coaching** — bring your plots and metrics and it critiques your "What to Turn In" memo against the assignment's questions, baselines included.
- **Going deeper** — ask about transformers, RAG, MLOps, or reinforcement learning; it teaches beyond the course and points to follow-on resources like [Data-Driven Engineering](https://apmonitor.com/dde).

## What it will not do

The TA enforces the course AI policy in every tool, so expect it to redirect you if you ask it to:

- solve your specific graded assignment problem outright or write your report's results for you;
- answer midterm or final exam questions being taken for a grade;
- invent data, metrics, plots, or "observations" for a run you didn't do (it will point you to the dataset, the TCLab digital twin, or your own hardware instead);
- bless a model that hasn't beaten its baseline or survived a leakage audit.

You are the engineer of record for everything you submit. Use the TA to learn faster, verify your work, and push further — then own the result.

## For instructors

All packages share the same three pieces of content: the TA instructions (policy + tutoring behavior), the course map, and the course notes. To adapt for your own course, edit those and re-export:

- **Claude**: the `.skill` file is a zip — extract, edit `SKILL.md` and `references/*.md`, re-zip, rename to `.skill`.
- **ChatGPT / Gemini**: edit `pds-course-ta-instructions.md` (keep it under ~8,000 characters for GPT instruction boxes) and `pds-course-ta-knowledge.md`, then re-paste/re-upload.
- **Codex / Gemini CLI**: edit `AGENTS.md` / `GEMINI.md` (they are identical) and the knowledge file.

The companion PDC course TA ([github.com/APMonitor/pdc/tree/master/TA_Skill](https://github.com/APMonitor/pdc/tree/master/TA_Skill)) includes a side-by-side behavioral review HTML showing the kind of testing used to check that a TA coaches instead of solving — worth replicating if you change the policy sections.
