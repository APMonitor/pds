# PDS Course TA - Knowledge File

Reference material for the Machine Learning for Engineers TA (apmonitor.com/pds).
Part 1 is the course map; Part 2 is the course notes (workflow, key results, misconceptions).

---

# Course Map - Machine Learning for Engineers (apmonitor.com/pds)

Base URL for course pages: `https://apmonitor.com/pds/index.php/Main/<PageName>`
TCLab notebooks: `https://apmonitor.com/pds/notebooks/<file>.html` · Companion lessons on Data-Driven Engineering: `https://apmonitor.com/dde/index.php/Main/<PageName>`

## 15-week schedule (week -> Topics | Assignment)

| Week | Topics (pages) | Assignment / case study |
|---|---|---|
| 1 | HomePage (Course Overview), intro to Python and ML; Quick Draw (quickdraw.withgoogle.com), TensorFlow Playground (playground.tensorflow.org) | InstallPython + InstallPythonPackages; Data-Driven Engineering modules (dde: PythonOverview); install the AI course TA skill; review AgenticWorkplan |
| 2 | DataPreparation (Data Engineering Part 1), GatherData, StatisticsMath, VisualizeData, CleanseData | Data Science with TCLab notebooks 1-4 (TCLabIntro is the umbrella page) |
| 3 | DataPreparation (Part 2), FeatureEngineering, ImbalancedData, ScaleData, SplitData | TCLab notebooks 5-8 |
| 4 | Regression: LinearRegression, KNearestNeighborsRegression, MultilayerPerceptronNeuralNetwork, SupportVectorRegressor, XGBoostRegressor; SteelPlateFaults; KNearestNeighbors (classifier, from-scratch exercise) | PolymerMeltFlowRate |
| 5 | Data types (dde lessons): DataStorage (Python data access), TextData, AudioAnalysis | AutomotiveMonitoring (also serves the PDC course's class-2 "Catalytic Converter Light-off" assignment, Case Study 1) |
| 6 | ClassificationOverview, CementStrength (Concrete Strength), CNN visualization (adamharley.com/nn_vis), LogisticRegression (from-scratch exercise) | SonarDetection (8 classifiers, confusion matrices) |
| 7 | Data collection with sensors (dde: SensorMeasurement) | - |
| 8 | CourseExam1 (midterm review + practice exam) | Midterm exam; AdditiveManufacturing case study (practice exam Part IV) |
| 9 | CourseProject | Project proposal |
| 10 | CourseProject | Progress report (data prep + multiple ML strategies + hyperparameter optimization) |
| 11 | CourseProject | Final report + presentation |
| 12 | Video data (dde: VideoData), ComputerVisionIntro, CascadeClassifier, VisionDeepLearning | RoadDetection, TextureClassification, BitClassification (Crack/Bit Classification) |
| 13 | Transformers (dde: LLMTransformers), LongShortTermMemory, LLMs (dde: LargeLanguageModel), dde: DatabaseAccess, SimilaritySearch, RAGLargeLanguageModel | - |
| 14 | DeployMachineLearning, cloud (dde: CloudAccess) | LSTMAutomation (Replace PID with LSTM on TCLab) |
| 15 | Final exams | WindPower (individual final), SafetySurveillance (group final) |

Case-study assignments end with a "What to Turn In" section: source code plus a short report/memo (PDF, 1-2 pages) answering listed questions with correct plots, honest test metrics, justifications, and assumptions. Students may use AI to help write it but own every claim.

## TCLab data science notebooks (weeks 2-3; graded on correctness, readability, modularity, comments)

Umbrella page: TCLabIntro ("Data Science with the TCLab"; thermal conductivity of metal/plastic/cardboard). Notebooks at `https://apmonitor.com/pds/notebooks/`:
01_overview, 02_import_export, 03_analyze (statistics), 04_visualize, 05_prepare_data (cleanse/scale/divide), 06_regression, 07_features, 08_classification, 09_interpolation, 10_solve_equations, 11_differential_equations, 12_time_series, XX_final (final TCLab project). TCLab_Help.html for hardware issues. `pip install tclab`; `tclab.setup(connected=False)` = digital twin (label simulated data as simulated).

## Data engineering pipeline pages (course sidebar order)

1 GatherData · 2 StatisticsMath · 3 VisualizeData · 4 CleanseData · 5 FeatureEngineering · 6 ImbalancedData · 7 ScaleData · 8 SplitData · 9 DeployMachineLearning · 10 AppDevelopment. Overview: DataPreparation.

## Agentic Engineering pages (the course's prompt-planning method; project workflow)

1 AgenticWorkplan (project workplans; Plan Mode; multi-agent orchestration) · 2 AgenticCoding (structured coding prompts, testing/validation, tools like Claude Code/Codex) · 3 AgenticCoordination (multi-agent roles, guardrails, conflict resolution) · 4 AgenticVisualization (plots/dashboards prompt builder) · 5 AgenticReports (Agentic Communication: report + presentation builders, responsible AI). Each has interactive prompt builders. Milestone mapping: Workplan -> proposal; Coding + Coordination -> progress report; Visualization + Communication -> final report/presentation.

## Method pages (the course model menu)

- Supervised classification: LogisticRegression, KNearestNeighbors, NaiveBayes, DecisionTree, RandomForest, AdaBoost, StochasticGradientDescent, SupportVectorClassifier, DeepLearningNeuralNetwork, XGBoostClassifier; HyperparameterOptimization.
- Unsupervised: KMeansClustering, GaussianMixtureModel, SpectralClustering.
- Regression: LinearRegression, KNearestNeighborsRegression, SupportVectorRegressor, GaussianProcessRegression, MultilayerPerceptronNeuralNetwork, XGBoostRegressor.
- Time series: ARXTimeSeries, LongShortTermMemory.
- Computer vision: ComputerVisionIntro, CascadeClassifier, VisionDeepLearning.

## Case-study / application pages (with the ML task)

| Page | Task |
|---|---|
| PolymerMeltFlowRate | Regress ln(MFR) from 7 reactor variables; 3 methods incl. linear regression + neural network; cleansing required; test R-squared |
| SonarDetection | 208 samples, 60 features, rock vs metal; 8 classifiers, test confusion matrices |
| AutomotiveMonitoring | OBD-II data (62 channels, 2 vehicles): catalyst light-off time to 500 degF + ARX model vs speed; GPS speed/elevation mapping; speed vs MPG |
| AdditiveManufacturing | 3D printing, n=70, 9 parameters; classify PLA/ABS (8+ classifiers) + regress tension strength (3 methods) |
| RoadDetection | OpenCV Demo_OpenCV.py: binary/edge/line/RGB/HSV features for lanes; student adds HSV split |
| TextureClassification | LBP (36 rotation-invariant bins) + SVM on sand/seed/stone; student adds a 4th material (5 train + 5 test photos) |
| BitClassification | Keras CNN: roller cone / PDC / spoon drill bits; concrete-crack extension (227x227 RGB) |
| LSTMAutomation | Train LSTM on PID/MPC data (inputs: setpoint + error window; output: heater %), deploy as TCLab controller, compare to PID; lstm_control.h5 + saved scalers |
| WindPower | Turkish 3.6 MW turbine, 10-min data, 1 yr; predict power 10 min ahead: XGBoost + NN (single row) vs LSTM (60-min window); MAE; feature importance; cleansing |
| SafetySurveillance | Group final: person detection (MediaPipe/YOLO), entry/exit timestamps to SQLite, alert/interlock when machinery running |
| Others: SteelPlateFaults, CementStrength, BatteryLife, LithiumIonBatteries, AutomotiveEfficiency, ThermophysicalProperties, GlassCharacterization, SoilClassification, DrawClassification, FacialRecognition, HandTracking, ActuatorMonitor (OT cybersecurity), CyberSecurity | Various |

## Other key pages

- CourseSchedule, CourseSyllabus, HomePage, CourseProject (proposal/progress/final requirements + 25 dataset suggestions), CourseExam1 (midterm review + 4-part practice exam), InstallPython, InstallPythonPackages, AIEthics, LearningResources, ShortCourse, StartupIncubator.
- AI course TA skill: https://github.com/APMonitor/pds/tree/master/TA_Skill (this skill).
- Related courses: Data-Driven Engineering https://apmonitor.com/dde (hosts week 5/7/13 lessons), Process Dynamics and Control https://apmonitor.com/pdc (TCLab control side; its class-2 assignment lives on this wiki at AutomotiveMonitoring), Dynamic Optimization https://apmonitor.com/do, Engineering Computing https://apmonitor.com/che263.

---

# Course Notes - Standard Workflow, Key Results, and Misconceptions

Use these forms and symbols so tutoring matches the course website. Verify any derived number against a limiting case or a baseline before presenting it.

## The standard ML workflow (data engineering pipeline)

The course teaches every problem through the same sequence (pages 1-8 are the data-prep steps; 9-10 are delivery):

1. **Gather** - import (pandas read_csv/read_excel/SQL, numpy loadtxt, web scraping) and consolidate (join on time index, append + drop_duplicates + sort_values).
2. **Statistics** - `data.describe()`, ydata-profiling; assess quality and diversity before modeling.
3. **Visualize** - pandas/matplotlib/plotly/seaborn; distribution questions -> histogram/box, relationship -> scatter/pair plot, linear association -> correlation heatmap.
4. **Cleanse** - remove/repair bad data: `dropna()`, `fillna(mean)` (dangerous on time series/multimodal), boolean filters, `z=z[~iz]` NaN-row removal. Always account: rows in, rows out, why. An outlier is not automatically bad data - in fault detection it may be the label.
5. **Features** - encode categoricals (ordinal only if truly ordered; one-hot if <~15 categories; hashing beyond), derive physics-informed features (e.g., temperature derivative to classify TCLab heater state), select with SelectKBest / SHAP.
6. **Balance** - for imbalanced labels: undersample majority (RandomUnderSampler) or oversample minority (SMOTE - synthetic interpolation in feature space). Rebalance TRAINING DATA ONLY, always after the split.
7. **Scale** - standard scaler z = (x - mu)/sigma (mean 0, std 1); min-max y = (x - x_min)/(x_max - x_min) (range 0-1). Fit the scaler on train only; transform (never refit) val/test; inverse-transform predictions before reporting engineering units. Trees/forests/XGBoost are scale-insensitive; kNN, SVM, and neural networks are highly sensitive.
8. **Split** - `train_test_split(..., test_size=0.2)`; typical 80/20. Validation set (or k-fold, `KFold(n_splits=5)`) for tuning; test set is looked at once. `shuffle=False` for time series. `stratify=y` preserves class ratios.
9. **Deploy** - pickle/save model + scalers together; monitor for drift.
10. **Apps** - wrap for users.

The course sometimes summarizes prep as "seven data science steps" in older material; the current site enumerates the eight prep steps above plus deploy/apps. Teach with the current site's numbering.

## Metrics (know the formulas)

Confusion matrix (binary, positive = class of interest): TP, FP, TN, FN.

- Accuracy = (TP+TN)/(TP+TN+FP+FN) - misleading when classes are imbalanced (predicting all-majority on 99:1 data scores 99%).
- Precision = TP/(TP+FP) - of the alarms raised, how many were real.
- Recall (sensitivity, TPR) = TP/(TP+FN) - of the real events, how many were caught. Protect recall when false negatives are expensive (mines, faults, intruders).
- Specificity = TN/(TN+FP). False positive rate = FP/(TN+FP) = 1 - specificity.
- F1 = 2·(precision·recall)/(precision+recall) - harmonic mean; use for imbalanced single-number comparison.

Regression:

- R² = 1 - SS_res/SS_tot, SS_res = Σ(y_i - ŷ_i)², SS_tot = Σ(y_i - ȳ)². R²=1 perfect; R²=0 no better than predicting the mean; R² < 0 possible on TEST data (worse than the mean predictor). Report train AND test R²; a large gap = overfitting.
- MAE = (1/n)Σ|y_i - ŷ_i| - robust, in data units (course standard for WindPower). RMSE = sqrt((1/n)Σ(y_i - ŷ_i)²) - penalizes large misses more. MAE ≤ RMSE always.
- Parity plot: predicted vs measured, points on the 45° line = good; curvature/fanning = structural error or heteroscedasticity. Residual plot vs inputs: structure = model missing something; random scatter = noise floor.

Baselines to demand before praising any model: majority-class (classification), mean predictor (regression), persistence forecast ŷ_{t+1} = y_t (time series). A model that does not beat its baseline is not a result.

## Bias-variance (the idea, as taught)

Expected test error decomposes conceptually as bias² + variance + irreducible noise. Simple/constrained models (large k in kNN, linear regression, shallow trees) have high bias, low variance - they underfit. Flexible models (k=1 kNN, deep trees, big networks) have low bias, high variance - they memorize noise and overfit. Symptoms: high train AND test error = bias; low train, high test error = variance. Fixes for variance: more data, regularization, simpler model, ensembling, early stopping (watch validation loss). The accuracy-vs-k plot in the kNN exercise is the course's canonical picture of this trade-off.

## Classifier menu (as taught, with sklearn idioms)

All follow: `model.fit(X_train, y_train)`, `y_pred = model.predict(X_test)`, `confusion_matrix(y_test, y_pred)`.

- Logistic regression: p = 1/(1+e^-(β₀+β₁x₁+...+βₙxₙ)); linear decision boundary; trained by minimizing log-loss (not squared error - convexity and probabilistic grounding); `LogisticRegression(C=..., max_iter=...)`. Coefficients = feature influence on log-odds. Needs scaling for clean convergence.
- k-nearest neighbors: lazy/instance-based, no training phase; distance vote among k neighbors; `KNeighborsClassifier(n_neighbors=k, metric=..., weights=...)`. Needs scaling (distance dominated by large-magnitude features); suffers in high dimensions.
- Naive Bayes: Bayes rule with feature-independence assumption; `GaussianNB()`; fast, surprisingly strong baseline.
- Decision tree: axis-aligned splits by impurity; `DecisionTreeClassifier(max_depth=...)`; interpretable, overfits when deep; no scaling needed.
- Random forest: bagged trees + feature subsampling; `RandomForestClassifier(n_estimators=...)`; variance reduction; `feature_importances_`.
- AdaBoost / XGBoost: sequential boosting of weak learners; `AdaBoostClassifier()`, `XGBClassifier()` (xgboost package); strong tabular default; no scaling needed.
- SVM: maximum-margin separator, kernels for nonlinearity; `SVC(kernel='rbf', C=...)`; needs scaling.
- Neural network: `MLPClassifier(hidden_layer_sizes=...)` or Keras Sequential; needs scaling; watch validation loss for overfitting.
- SGD: linear model trained by stochastic gradient descent; `SGDClassifier()`; scales to large data.
- Unsupervised: `KMeans(n_clusters=...)`, `GaussianMixture(...)`, `SpectralClustering(...)`; k-means can flag minority/anomaly groups when labels are absent.

Regressor menu mirrors it: `LinearRegression()`, `KNeighborsRegressor()`, `SVR()`, `GaussianProcessRegressor()` (gives uncertainty bands), `MLPRegressor()`/Keras, `XGBRegressor()`.

CNNs (weeks 12): Conv2D layers learn local, translation-tolerant patterns; MaxPooling2D downsamples; Dense + softmax head; categorical crossentropy loss, Adam optimizer; `ImageDataGenerator` for augmentation (flip/rotate/shift - only augmentations that preserve the label). Train-high/test-low accuracy gap = overfitting: augment, simplify, or get data. One-line modern context: vision transformers rival CNNs at large data scale; small engineering datasets still favor CNNs + augmentation. Classical CV (RoadDetection): HSV separates color from illumination; Canny edges (two thresholds); Hough lines; morphological opening removes small specks; LBP (TextureClassification) encodes local texture, rotation-invariant form has 36 bins here.

## Train/validation/test discipline (the course's core rules)

- Test set is touched once, for the final number. Tuning against it (repeatedly) makes it a validation set and the reported score dishonest.
- Everything data-dependent (scaler statistics, SMOTE, feature selection, imputation values) is FIT on training data only, inside the split (ideally a `Pipeline`).
- Time series: `shuffle=False`; never let the model train on the future. For forecasting, compare against persistence.
- Near-duplicates (repeated experiments, frames of the same object/person, augmented images) must not span the split - split by group, not by row.
- Small n (AdditiveManufacturing has 70 rows): single-split results are noisy; use k-fold cross-validation and report spread; rerun with a different random_state before believing a ranking (SonarDetection, n=208).
- Synthetic data (SMOTE or generative): interpolated samples may be physically unrealizable and can smooth over true class boundaries; never let synthetic points reach the test set; disclose their use.

## ARX and LSTM (time series / automation pages)

**ARX** (AutoRegressive with eXogenous input), as on ARXTimeSeries and used in AutomotiveMonitoring:

y_{k+1} = Σ_{i=1..na} a_i · y_{k-i+1} + Σ_{i=1..nb} b_i · u_{k-i+1}

- na, nb = number of output/input lags; a_i, b_i fit by least squares.
- Stability: roots of the characteristic polynomial inside the unit circle (quick screen: Σa_i < 1 for simple cases).
- Steady-state gain = (Σb_i)/(1 - Σa_i) - sanity-check its sign and magnitude against physics (e.g., degF of catalyst temperature per mph).
- Judge fit on data NOT used for fitting; one-step-ahead predictions flatter any model - multi-step simulation is the honest test.

**LSTM** (LongShortTermMemory, LSTMAutomation, WindPower):

- Recurrent network with gates (input/forget/output) that keep a cell state across steps; practical course-level view: it maps a WINDOW of past values to the next value.
- Data prep: scale inputs and outputs (save the scalers!); reshape to (samples, timesteps, features); `shuffle=False` splitting.
- WindPower: single-row models (XGBoost/MLP) vs LSTM on a 60-min (6-sample) window, 10 min ahead, MAE metric; at short horizons prior power dominates and persistence is hard to beat.
- LSTMAutomation: the LSTM learns to IMITATE the PID/MPC that generated its training data (inputs: recent setpoint + error window; output: heater 0-100%). It cannot exceed its teacher; training data must excite the whole operating range; out-of-distribution inputs produce unpredictable commands - the central safety issue. Deployment: load lstm_control.h5 + the saved scalers + window hyperparameters (pickle); judge closed-loop on hardware against the PID, not by training-set fit.

## Common misconceptions to watch for

- "High accuracy = good model": on imbalanced data accuracy tracks the majority class; ask for the confusion matrix, precision/recall, and the majority-class baseline.
- "Scale/SMOTE/select features first, then split": leakage - test-set statistics contaminate training; scores inflate. The single most common student (and paper) bug.
- "Outliers should be removed": not when the outlier is the event of interest (faults, cracks, intruders).
- "R² is high so the model is right on new conditions": R² is measured on the data's range; extrapolation outside training range is unguaranteed (polymer reactor, wind turbine curtailment, LSTM controller).
- "Train R² is what matters": report test; the gap is the overfitting diagnostic.
- "The test set proves it - I checked it many times": repeated checking = tuning on test; keep a final untouched set.
- "kNN trains fast so it's cheap": prediction is the expensive part (distance to all training points); it also degrades unscaled and in high dimensions.
- "One-hot always": >15 categories blows up features; ordinal encoding of unordered categories invents a false order.
- "Random split is always fine": not for time series (future leaks into training) or grouped/near-duplicate data (same object both sides).
- "Loss went down so it converged": check validation loss for the upturn (overfit) and learning-rate symptoms (oscillation vs crawl).
- "The LSTM beat the PID because training error was tiny": training fit is not closed-loop performance; small errors compound through feedback.
- "Correlation heatmap shows causation / all relationships": linear association only, confounders abound (PV example: hot hours are sunny hours, yet cells are less efficient hot).
- "More data always fixes it": biased or leaky data at larger volume is just a more confident wrong answer; diagnose with statistics/visualization first.
- "AI wrote it and it runs, so it's correct": running is not verified; demand a baseline, a leakage audit, and one known-answer check per pipeline.

## Verification habits to model and demand

State the baseline before the model; account for every dropped row; fit-on-train-only for every data-dependent step; different random_state rerun before trusting a ranking; parity + residual plots, not just one number; inverse-transform to engineering units; and on TCLab pages, the student's own hardware/digital-twin run is the final referee - never fabricated data.
